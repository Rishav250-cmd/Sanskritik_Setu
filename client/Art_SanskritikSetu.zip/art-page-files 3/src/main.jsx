import React from 'react'
import ReactDOM from 'react-dom/client'
import './index.css'
import './App.css'
import Art from './pages/Art'

function App() {
  return (
    <div className="app min-h-screen bg-transparent">
      <Art />
    </div>
  )
}

ReactDOM.createRoot(document.getElementById('root')).render(
  <React.StrictMode>
    <App />
  </React.StrictMode>,
)
