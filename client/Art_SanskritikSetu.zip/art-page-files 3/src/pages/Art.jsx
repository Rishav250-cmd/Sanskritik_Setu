import React from 'react'
import ArtHero from '../components/art/ArtHero'
import ArtCategorySection from '../components/art/ArtCategorySection'
import StateArtSection from '../components/art/StateArtSection'

function Art() {
  return (
    <main className="content text-white">
      <ArtHero />
      <ArtCategorySection />
      <StateArtSection />
    </main>
  )
}

export default Art
