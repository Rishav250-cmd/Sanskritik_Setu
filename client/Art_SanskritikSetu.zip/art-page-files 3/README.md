# Sanskritik Setu — Art & Expressions

Standalone Vite + React version of the Art & Expressions page.

## Requirements

- Node.js 18+ (Node.js 20+ recommended)
- VS Code

## Run locally

Open this folder in VS Code — the folder containing `package.json`.

Then open the VS Code terminal and run:

```bash
npm install
npm run dev
```

Open the local URL printed by Vite, usually `http://localhost:5173`.

## Production build

```bash
npm run build
npm run preview
```

## Notes

- This standalone project does not require GitHub.
- The Art page uses the supplied component/data files.
- Images currently use seeded `picsum.photos` URLs from `src/data/artData.js` so they can be replaced later with local or final cultural-heritage assets.
